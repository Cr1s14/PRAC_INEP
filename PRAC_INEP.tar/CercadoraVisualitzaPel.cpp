#include "CercadoraVisualitzaPel.h"

int CercadoraVisualitzaPel::cercaVisualitzacions(string sobrenom) {
	string query = "SELECT num_visualitzacions FROM visualitzacio_pelicula WHERE sobrenom_usuari = '" + sobrenom + "'";
	ConnexioBD2& con = ConnexioBD2::getInstance();
	sql::ResultSet* res = con.consulta(query);
	int visualitzacions = 0;
	if (res->next()) {
		int visualitzacions = res->getInt("num_visualitzacions");
		delete res;
		return visualitzacions;

	} 
	return visualitzacions;
}