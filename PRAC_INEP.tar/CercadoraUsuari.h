#include "PassarelaUsuari.h"
class CercadoraUsuari {
	private:
	public:
		CercadoraUsuari() {
		}
		PassarelaUsuari cercaUsuari(string sobrenom);
};

