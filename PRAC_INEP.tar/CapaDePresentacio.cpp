#include "CapaDePresentacio.h"
using namespace std;


void CapaDePresentacio::IniciSessio() {
	string sobrenomU, contrasenyaU;
	wcout << "** Inici sessi� **" << endl;
	cout << "Sobrenom: ";
	cin >> sobrenomU;
	cout << "Contrasenya: ";
	cin >> contrasenyaU;
	TxIniciSessio tx(sobrenomU, contrasenyaU);
	try {
		tx.executar();
		wcout << "Sessi� iniciada correctament!" << endl;
	}
	catch (const exception& e) {
		cout << "Error:" << e.what() << endl;
	}
	//Mostra missatge "Hi ha hagut un error amb el sobrenom o la contrasenya"
}

void CapaDePresentacio::TancaSessio() {
	char resposta;
	wcout << "Vols tancar la sessi�? (S/N):";
	cin >> resposta;
	TxTancaSessi� tx;
	if (resposta == 'S') {
		tx.executar();
		wcout << "Sessi� tancada correctament" << endl;
	}	
}

void CapaDePresentacio::RegistrarUsuari() {
	string sobrenomU, nomU, correuU, contrasenyaU, dataNaixementU,subscripcioU;
	cout << "** Registrar usuari **" << endl;

	cout << "Nom complet: ";
	cin.ignore(numeric_limits<streamsize>::max(), '\n');
	getline(cin, nomU);

	cout << "Sobrenom: ";
	getline(cin, sobrenomU);

	cout << "Contrasenya: ";
	getline(cin, contrasenyaU);

	wcout << "Correu electr�nic: ";
	getline(cin, correuU);

	cout << "Data naixement (DD/MM/AAAA): ";
	getline(cin, dataNaixementU);

	wcout << "Modalitats de subscripci� disponibles" << endl;
	cout << " > 1. Completa" << endl;
	wcout << " > 2. Cin�fil" << endl;
	cout << " > 3. Infantil" << endl;
	cout << "Escull modalitat: ";
	int opciosubscripcioU;
	cin >> opciosubscripcioU;

	switch (opciosubscripcioU) {
	case 1:
		subscripcioU = "Completa";
		break;
	case 2:
		subscripcioU = "Cinefil";
		break;
	case 3:
		subscripcioU = "Infantil";
		break;
	default:
		cout << "Modalitat no existeix" << endl;
		return;
	}

	TxRegistraUsuari tx(sobrenomU, nomU, correuU, contrasenyaU, dataNaixementU, subscripcioU);
	try {
		tx.executar();
			cout << "Usuari registrat correctament!" << endl;
	}
	catch (const exception& e) {
		cout << "Error:" << e.what() << endl;
	}
}

void CapaDePresentacio::ConsultaUsuari() {
	TxConsultaUsuari tx;
	TxInfoVisualitzacions tx2;
	try {
		tx.executar();
		tx2.executar();
		DTOUsuari infoUsuari = tx.obteResultat();
		pair<int, int> infoVisualitzacions = tx2.obteResultat();
		cout << "** Consulta Usuari **"<< endl;
		cout << "Nom complet: " << infoUsuari.obteNom() << endl;
		cout << "Sobrenom: " << infoUsuari.obteSobrenom() << endl;
		wcout << "Correu electr�nic: ";
		cout << infoUsuari.obteCorreu() << endl;
		cout << "Data naixement (DD/MM/AAAA): " << infoUsuari.obteDataNaixement() << endl;	
		wcout << "Modalitat subscripci�: ";
		cout << infoUsuari.obteSubscripcio() << endl;		
		cout << endl;
		cout << infoVisualitzacions.first;
		wcout << " pel�l�cules visualitzades" << endl;
		cout << infoVisualitzacions.second;
		wcout << " cap�tols visualitzats" << endl;
	}
	catch (const exception& e) {
		cout << "Error:" << e.what() << endl;
	}
}

void CapaDePresentacio::ModificaUsuari() {
	string camp,nomU,contraU,correuU,neixU,modalitatU;
	nomU = contraU = correuU = neixU = modalitatU = "";
	cout << "** Modifica Usuari **" << endl;
	CtrlModificaUsuari ctrl;
	try {
		DTOUsuari infoU = ctrl.consultaUsuari();
		cout << "Nom complet: " << infoU.obteNom() << endl;
		cout << "Sobrenom: " << infoU.obteSobrenom() << endl;
		wcout << "Correu electr�nic: ";
		cout << infoU.obteCorreu() << endl;
		cout << "Data naixement (DD/MM/AAAA): " << infoU.obteDataNaixement() << endl;
		wcout << "Modalitat subscripci�: ";
		cout << infoU.obteSubscripcio() << endl;

		nomU = infoU.obteNom();
		correuU = infoU.obteCorreu();
		neixU = infoU.obteDataNaixement();
		modalitatU = infoU.obteSubscripcio();

		cout << endl;

		wcout << "Omplir la informaci� que es vol modificar ..." << endl;

		cout << "Nom complet: ";
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		getline(cin, camp);
		if (!camp.empty()) {
			nomU = camp;
		}

		cout << "Contrasenya: ";
		getline(cin, camp);
		if (!camp.empty()) {
			contraU = camp;
		}

		wcout << "Correu electr�nic: ";
		getline(cin, camp);
		if (!camp.empty()) {
			correuU = camp;
		}	

		cout << "Data naixement (DD/MM/AAAA): ";
		getline(cin, camp);	
		if (!camp.empty()) {
			neixU = camp;
		}	

		wcout << "Modalitat subscripci�: ";
		getline(cin, camp);	
		if (!camp.empty()) {
			modalitatU = camp;
		}

		ctrl.modificaUsuari(nomU, contraU, correuU, neixU, modalitatU);
		cout << endl;

		infoU = ctrl.consultaUsuari();
		cout << "** Dades usuari modificades **" << endl;
		cout << "Nom complet: " << infoU.obteNom() << endl;
		cout << "Sobrenom: " << infoU.obteSobrenom() << endl;
		wcout << "Correu electr�nic: ";
		cout << infoU.obteCorreu() << endl;
		cout << "Data naixement (DD/MM/AAAA): " << infoU.obteDataNaixement() << endl;
		wcout << "Modalitat subscripci�: ";
		cout << infoU.obteSubscripcio() << endl;
	}
	catch (const exception& e) {
		cout << "Error:" << e.what() << endl;
	}

}

void CapaDePresentacio::EsborraUsuari() {
	cout << "** Esborra Usuari **" << endl;
	cout << "Per confirmar l'esborrat, s'ha d'entrar la contrasenya ..." << endl;
	string contraU;
	cout << "Contrasenya: ";
	cin >> contraU;
	TxEsborraUsuari tx(contraU);
	try {
		tx.executar();
		cout << "Usuari s'esborrat correctament" << endl;
	
	}
	catch (const exception& e) {
		cout << "Error:" << e.what() << endl;
	}
	// Mostra missatge "La contrasenya no �s correcta. l'usuari no s'esborrat"
	// sin�, mostra missatge "Usuari no s'esborrat correctament"
}