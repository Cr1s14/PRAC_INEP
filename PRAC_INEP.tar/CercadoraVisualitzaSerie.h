#pragma once
#include <iostream>
#include "ConnexioBD2.h"

using namespace std;

class CercadoraVisualitzaSerie {
	private:
public:
	CercadoraVisualitzaSerie() {
	}
	int cercaVisualitzacions(string sobrenom);
};

