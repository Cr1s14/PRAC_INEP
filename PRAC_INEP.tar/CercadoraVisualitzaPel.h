#pragma once
#include <iostream>
#include "ConnexioBD2.h"

using namespace std;

class CercadoraVisualitzaPel {
	private:
	public:
		CercadoraVisualitzaPel() {
		}
		int cercaVisualitzacions(string sobrenom);
};

